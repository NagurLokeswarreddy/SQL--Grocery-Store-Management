-- How many orders have been placed in total?--
select count(*) AS total_orders from orders;

-- What is the average value per order?--
SELECT AVG(order_total) AS avg_order_value
FROM (
    SELECT od.ord_id, SUM(od.quantity * od.each_price) AS order_total
    FROM order_details od
    GROUP BY od.ord_id
) AS sub;


-- On which dates were the most orders placed?--
SELECT order_date, COUNT(ord_id) AS total_orders
FROM orders
GROUP BY order_date
ORDER BY total_orders DESC
LIMIT 5;  

-- What are the monthly trends in order volume and revenue?--
SELECT 
    DATE_FORMAT(o.order_date, '%Y-%m') AS month,
    COUNT(o.ord_id) AS total_orders,
    SUM(od.quantity * od.each_price) AS total_revenue
FROM orders o
INNER JOIN order_details od ON o.ord_id = od.ord_id
GROUP BY DATE_FORMAT(o.order_date, '%Y-%m')
ORDER BY month;

-- How do order patterns vary across weekdays and weekends?--
SELECT 
    CASE 
        WHEN DAYOFWEEK(order_date) IN (1,7) THEN 'Weekend'  -- Sunday & Saturday
        ELSE 'Weekday'
    END AS day_type,
    COUNT(DISTINCT o.ord_id) AS total_orders,
    SUM(od.quantity * od.each_price) AS total_sales,
    ROUND(AVG(od.quantity * od.each_price),2) AS avg_order_value
FROM orders o
JOIN order_details od ON o.ord_id = od.ord_id
GROUP BY day_type;




