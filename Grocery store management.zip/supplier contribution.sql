-- How many suppliers are there in the database?--
SELECT COUNT(*) AS total_suppliers
FROM supplier;

-- Which supplier provides the most products?-- 

SELECT 
    s.sup_id,
    s.sup_name,
    COUNT(p.prod_id) AS total_products
FROM supplier s
JOIN products p ON s.sup_id = p.sup_id
GROUP BY s.sup_id, s.sup_name
ORDER BY total_products DESC
LIMIT 1;

-- What is the average price of products from each supplier?--

SELECT 
    s.sup_id,
    s.sup_name,
    ROUND(AVG(p.price), 2) AS avg_price
FROM supplier s
JOIN products p ON s.sup_id = p.sup_id
GROUP BY s.sup_id, s.sup_name
ORDER BY avg_price DESC;

-- Which suppliers contribute the most to total product sales (by revenue)?-- 

SELECT 
    s.sup_id,
    s.sup_name,
    ROUND(SUM(od.quantity * od.each_price), 2) AS total_revenue
FROM supplier s
JOIN products p ON s.sup_id = p.sup_id
JOIN order_details od ON p.prod_id = od.prod_id
GROUP BY s.sup_id, s.sup_name
ORDER BY total_revenue DESC;
