create database GSM;
use GSM;

-- 1. Supplier Table
CREATE TABLE IF NOT EXISTS supplier (
    sup_id INT AUTO_INCREMENT PRIMARY KEY,
    sup_name VARCHAR(255) NOT NULL,
    address VARCHAR(500) NOT NULL
);

-- 2. Categories Table
CREATE TABLE IF NOT EXISTS categories (
    cat_id INT AUTO_INCREMENT PRIMARY KEY,
    cat_name VARCHAR(255) NOT NULL
);

drop table employees;
-- Employees table 
CREATE TABLE IF NOT EXISTS employees (
    emp_id INT AUTO_INCREMENT PRIMARY KEY,
    emp_name VARCHAR(255) NOT NULL,
    hire_date varchar(255)
);


drop table customers;
-- 4. Customers Table
CREATE TABLE IF NOT EXISTS customers (
    cust_id INT AUTO_INCREMENT PRIMARY KEY,
    cust_name VARCHAR(255) NOT NULL,
    address VARCHAR(500) NOT NULL
);

-- 5. Products Table
CREATE TABLE IF NOT EXISTS products (
    prod_id INT AUTO_INCREMENT PRIMARY KEY,
    prod_name VARCHAR(255) NOT NULL,
    sup_id INT NOT NULL,
    cat_id INT NOT NULL,
    price DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (sup_id) REFERENCES supplier(sup_id)
        ON UPDATE CASCADE ON DELETE CASCADE,
    FOREIGN KEY (cat_id) REFERENCES categories(cat_id)
        ON UPDATE CASCADE ON DELETE CASCADE
);
drop table orders;
-- 6. Orders Table
CREATE TABLE IF NOT EXISTS orders (
    ord_id INT AUTO_INCREMENT PRIMARY KEY,
    cust_id INT NOT NULL,
    emp_id INT NOT NULL,
    order_date varchar(255),
    FOREIGN KEY (cust_id) REFERENCES customers(cust_id)
        ON UPDATE CASCADE ON DELETE CASCADE,
    FOREIGN KEY (emp_id) REFERENCES employees(emp_id)
        ON UPDATE CASCADE ON DELETE CASCADE
);
drop table order_details;

CREATE TABLE IF NOT EXISTS order_details (
    ord_detID INT AUTO_INCREMENT PRIMARY KEY,
    ord_id INT NOT NULL,
    prod_id INT NOT NULL,
    quantity TINYINT NOT NULL,
    each_price DECIMAL(10,2) NOT NULL,
    TotalPrice DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (ord_id) REFERENCES orders(ord_id)
        ON UPDATE CASCADE ON DELETE CASCADE,
    FOREIGN KEY (prod_id) REFERENCES products(prod_id)
        ON UPDATE CASCADE ON DELETE CASCADE
);




    
