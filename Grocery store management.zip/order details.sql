-- What is the relationship between quantity ordered and total price?--

SELECT 
    ord_detID,
    quantity,
    each_price,
    ROUND(quantity * each_price, 2) AS total_price
FROM order_details
ORDER BY total_price DESC;

-- What is the average quantity ordered per product?--

SELECT 
    p.prod_id,
    p.prod_name,
    ROUND(AVG(od.quantity), 2) AS avg_quantity_ordered
FROM products p
JOIN order_details od ON p.prod_id = od.prod_id
GROUP BY p.prod_id, p.prod_name
ORDER BY avg_quantity_ordered DESC;

-- How does the unit price vary across products and orders?--

SELECT 
    prod_id,
    prod_name,
    price AS unit_price
FROM products
ORDER BY unit_price DESC;

