-- How many employees have processed orders?-- 

SELECT COUNT(DISTINCT emp_id) AS employees_with_orders
FROM orders;

-- Which employees have handled the most orders?-- 

SELECT 
    e.emp_id,
    e.emp_name,
    COUNT(o.ord_id) AS total_orders
FROM employees e
JOIN orders o ON e.emp_id = o.emp_id
GROUP BY e.emp_id, e.emp_name
ORDER BY total_orders DESC;

-- What is the total sales value processed by each employee?-- 

SELECT 
    e.emp_id,
    e.emp_name,
    ROUND(SUM(od.quantity * od.each_price), 2) AS total_sales
FROM employees e
JOIN orders o ON e.emp_id = o.emp_id
JOIN order_details od ON o.ord_id = od.ord_id
GROUP BY e.emp_id, e.emp_name
ORDER BY total_sales DESC;

-- What is the average order value handled per employee?-- 

SELECT 
    e.emp_id,
    e.emp_name,
    ROUND(SUM(od.quantity * od.each_price) / COUNT(DISTINCT o.ord_id), 2) AS avg_order_value
FROM employees e
JOIN orders o ON e.emp_id = o.emp_id
JOIN order_details od ON o.ord_id = od.ord_id
GROUP BY e.emp_id, e.emp_name
ORDER BY avg_order_value DESC;


