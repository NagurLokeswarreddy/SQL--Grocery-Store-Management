select * from supplier;
select * from categories;
select * from employees;
select * from customers;
select * from products;
select * from orders;
select * from order_details;

-- How many unique customers have placed orders?--
select COUNT(DISTINCT cust_id) as unique_customers
from orders;

-- Which customers have placed the highest number of orders?--
SELECT c.cust_name, COUNT(o.ord_id) AS total_orders
FROM customers c
inner join orders o ON c.cust_id = o.cust_id
GROUP BY c.cust_id, c.cust_name
ORDER BY total_orders DESC;

-- What is the total and average purchase value per customer?--
SELECT 
    c.cust_id,
    c.cust_name,
    SUM(od.TotalPrice) AS total_purchase_value,
    AVG(od.TotalPrice) AS average_purchase_value,
    COUNT(o.ord_id) AS total_orders
FROM customers c
INNER JOIN orders o ON c.cust_id = o.cust_id
INNER JOIN order_details od ON o.ord_id = od.ord_id
GROUP BY c.cust_id, c.cust_name
ORDER BY total_purchase_value DESC;

-- Who are the top 5 customers by total purchase amount?--
SELECT c.cust_name, 
       SUM(od.quantity * od.each_price) AS total_purchase_value
FROM customers c
INNER JOIN orders o ON c.cust_id = o.cust_id
INNER JOIN order_details od ON o.ord_id = od.ord_id
GROUP BY c.cust_id, c.cust_name
ORDER BY total_purchase_value DESC
LIMIT 5;

